
Implementa��o do que foi proposto no teste, utilizando recursos da linguagem Java sem Frameworks, sem uso de databases. 
O arquivo de input de dados � lido na classe DataService e inserido em ArrayList.
Separa��o em camadas Model, Service e Repository, conforme princ�pios DDD.
O arquivo de log.txt est� na raiz do projeto.
O arquivo resultado.txt pode ser apagado, porque ser� gravado sempre que o projeto for executado.
Para mostrar de novo o resultado.txt, caso tenha diso deletado, fazer um refresh.
Ambiente de desenvolvimento:
 Eclipse JEE2019-12.
 Sistema Operacional Windows.

Run Application

Obs : Roda no Console e escreve em arquivo texto.


https://github.com/v-a-branquinho/criar