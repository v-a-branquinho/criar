package factory;

import model.Corrida;
import service.CorridaService;
import service.DataService;
import service.PilotoService;

public class CorridaFactory {
	
	private static CorridaFactory uniqueInstance;
	private static CorridaService corridaService;
	private static PilotoService pilotoService;
	private static DataService dataService;
	

	private CorridaFactory() {
		corridaService = new CorridaService();
		pilotoService = new PilotoService();
		
		criarPilotos();
		Corrida corrida = new Corrida();
		corrida.montarGridDeLargada();
		corrida.start();
		
		dataService = new DataService();
		
		CorridaService corridaService = new CorridaService();
		corridaService.calcularVelocidadeMedia();
	}

	public static CorridaFactory getInstance(){
		if (uniqueInstance == null){
			uniqueInstance = new CorridaFactory();
		}
		return uniqueInstance;
	}
	
	private void criarPilotos() {
		pilotoService.inserirPiloto( );
	}


}
