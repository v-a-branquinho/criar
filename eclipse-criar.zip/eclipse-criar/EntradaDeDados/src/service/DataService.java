package service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import model.DataRow;
import repository.DataRepository;

public class DataService {

	private static DataRepository dataRepository;
	private static String arquivo;
	private static String readMe;

	static {
		dataRepository = new DataRepository();
	}

	public static void lerArquivo() {
		DataService ds = new DataService();
		try (Scanner scan = new Scanner(new File("log.txt"))) {
			String line;
			while (scan.hasNextLine()) {
				line = scan.nextLine();
				ds.inserirDataRow(line);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

	public static void escreverSaida( ) {

		try (PrintWriter pw = new PrintWriter("resultado.txt")) {
			pw.print(arquivo);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static void escreverArquivo(String texto) {
		arquivo+="\n"+texto;
	
	}
	
	public static void escreverReadMe(String texto) {
		try (PrintWriter pw = new PrintWriter("readMe.txt")) {
			pw.print(texto);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void inserirDataRow(String line) {

		String[] tokens = line.split(" ");
		String hora = tokens[0];
		String codigo = tokens[1];
		String nome = tokens[3];
		String volta = tokens[4];
		String tempoDaVolta = tokens[5];
		String velocidadeMedia = tokens[6];

		DataRow dr = new DataRow();

		dr.setHora(hora);
		dr.setCodigo(codigo);
		dr.setNome(nome);
		dr.setVolta(volta);
		dr.setTempoDaVolta(tempoDaVolta);
		dr.setVelocidadeMedia(velocidadeMedia);
		dataRepository.create(dr);

	}

	public int getNumeroTotalDeVoltas() {
		int totalDeVoltas = DataRepository.numeroTotalDeVoltas;
		return totalDeVoltas;
	}

}
