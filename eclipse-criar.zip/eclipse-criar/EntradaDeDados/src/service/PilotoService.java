package service;

import repository.PilotoRepository;

public class PilotoService {
	
	PilotoRepository pilotoRepository = new PilotoRepository();
	
	public PilotoService() {
		
	}
	
	public void inserirPiloto() {
		
		pilotoRepository.create();

	}
	
	
}


