package service;

import repository.CorridaRepository;
import repository.DataRepository;

public class CorridaService {
	
	private CorridaRepository corridaRepository = new CorridaRepository();
	private DataRepository dataRepository = new DataRepository();
	private String gridDeLargada="";
	
	public CorridaService() {
	 
	}

	public String formarGrid() {
		gridDeLargada =  corridaRepository.formarGrid();
		return gridDeLargada;	
	}
	
	public String listarPosicoes(String volta) {
		String posicoes = corridaRepository.listarPosicoesPorVolta(volta);
		return posicoes;
	}
	
	public String getMenorTempoDaVolta() {
		String resultado = dataRepository.findByMenorTempoDaVolta();
		return resultado;
	}
	
	public void calcularVelocidadeMedia() {
		
	}

}
