import service.DataService;

public class ReadMe {
	
	public static String readMe="";
	
	public static void escreverReadMe() {
		readMe+="\n"
				+ "Implementa��o do que foi proposto no teste, utilizando recursos da linguagem Java sem Frameworks, sem uso de databases. "
				+ "\nO arquivo de input de dados � lido na classe DataService e inserido em ArrayList."
				+ "\nSepara��o em camadas Model, Service e Repository, conforme princ�pios DDD."
				+ "\nO arquivo de log.txt est� na raiz do projeto."
				+ "\nO arquivo resultado.txt pode ser apagado, porque ser� gravado sempre que o projeto for executado."
				+ "\nPara mostrar de novo o resultado.txt, caso tenha diso deletado, fazer um refresh."
				+ "\nAmbiente de desenvolvimento:"
				+ "\n Eclipse JEE2019-12."
				+ "\n Sistema Operacional Windows."
				+ "\n"
				+ "\n"
				+ "Run Application"
				+ "\n"
				+ "\n"
				+ "Obs : Roda no Console e escreve em arquivo texto.";
		
		DataService.escreverReadMe(readMe);
	}
	
}
