package metodosUteis;

public class Utils {

	public Double convertHoursToSeconds(String hours) {
		Double numero = Double.parseDouble(hours);
		Double segundos = numero * 60 * 60;
		return segundos;

	}

	public Double convertMinutsToSeconds(String minuts) {
		Double numero = Double.parseDouble(minuts);
		Double segundos = numero * 60;
		return segundos;

	}

	// entrada -> horas:minutos:segundos:milesimos
	// saida -> segundos.mil�simos
	public Double convertTimeToSeconds(String horasMinutosSegundosMilesimos) {

		String[] tokens = horasMinutosSegundosMilesimos.split(":");
		Double segundos = convertHoursToSeconds(tokens[0]);
		segundos += convertMinutsToSeconds(tokens[1]);
		segundos += Double.parseDouble(tokens[2]);
		segundos += Double.parseDouble(tokens[3]) / 1000;
		return segundos;
	}

	// entrada -> segundos.mil�simos
	// formato de sa�da -> horas:minutos:segundos:milesimos
	public String convertSecondsToMinutesToHours(String segundos) {
		Integer hours;
		Integer minuts;
		Integer seconds;
		Integer milesimos;

		String[] sm = segundos.split(".");
		seconds = Integer.parseInt(sm[0]);
		milesimos = Integer.parseInt(sm[1]);
		String _milesimos = sm[1];

		if (seconds < 60) {
			minuts = 0;
			hours = 0;
			String hmsm = "0" + ":" + "00" + ":" + sm[0] + ":" + _milesimos;
			return hmsm;
		}

		minuts = seconds / 60;
		seconds = seconds - (minuts * 60);

		if (minuts < 60) {
			hours = 0;
			String minutos = String.valueOf(minuts);
			String _segundos = String.valueOf(seconds);
			String hmsm = "0" + ":" + minutos + ":" + _segundos + ":" + _milesimos;
			return hmsm;
		}

		hours = minuts / 60;
		minuts = minuts - (hours * 60);

		String _hours = String.valueOf(hours);
		String _minutos = String.valueOf(minuts);
		String _seconds = String.valueOf(seconds);
		String hmsm = _hours + ":" + _minutos + ":" + _seconds + ":" + _milesimos;
		return hmsm;

	}

	public String menor(String data1, String data2) {
		String menorTempo = "";
		return menorTempo;
	}

	// unidade de distancia -> metros
	// unidade de velocidade -> metros/segundo
	public Double calcularVelocidadeMedia(Double distancia, Double segundos) {
		return distancia / segundos;
	}

	// unidade de velocidade -> metros/segundo
	public Double calcularDistancia(Double velocidade, Double segundos) {
		return velocidade * segundos;
	}

}
