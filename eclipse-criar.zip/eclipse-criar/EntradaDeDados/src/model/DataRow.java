package model;

import java.util.Comparator;

public class DataRow {

	private String hora;
	private String codigo;
	private String nome;
	private String volta;
	private String tempoDaVolta;
	private String velocidadeMedia;

	public DataRow() {

	}

	public static Comparator<DataRow> tempoDaVoltaComparator = new Comparator<DataRow>() {
		@Override
		public int compare(DataRow dr1, DataRow dr2) {
			return (int) (dr1.getTempoDaVolta().compareTo(dr2.getTempoDaVolta()));
		}
	};
	
	public static Comparator<DataRow> horaComparator = new Comparator<DataRow>() {
		@Override
		public int compare(DataRow dr1, DataRow dr2) {
			return (int) (dr1.getHora().compareTo(dr2.getHora()));
		}
	};
	
	public static Comparator<DataRow> velocidadeMediaComparator = new Comparator<DataRow>() {
		@Override
		public int compare(DataRow dr1, DataRow dr2) {
			return (int) (dr1.getVelocidadeMedia().compareTo(dr2.getVelocidadeMedia()));
		}
	};
	

	@Override
	public String toString() {
		return "DataRow [hora=" + hora + ", codigo=" + codigo + ", nome=" + nome + ", volta=" + volta
				+ ", tempoDaVolta=" + tempoDaVolta + ", velocidadeMedia=" + velocidadeMedia + "]";
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getVolta() {
		return volta;
	}

	public void setVolta(String volta) {
		this.volta = volta;
	}

	public String getTempoDaVolta() {
		return tempoDaVolta;
	}

	public void setTempoDaVolta(String tempoDaVolta) {
		this.tempoDaVolta = tempoDaVolta;
	}

	public String getVelocidadeMedia() {
		return velocidadeMedia;
	}

	public void setVelocidadeMedia(String velocidadeMedia) {
		this.velocidadeMedia = velocidadeMedia;
	}

}
