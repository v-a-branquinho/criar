package model;

import service.CorridaService;
import service.DataService;

public class Corrida {

	private CorridaService corridaService = new CorridaService();
	private DataService dataService = new DataService();

	private int numeroDeVoltas;
	private String gridDeLargada;
	

	public Corrida() {
		this.numeroDeVoltas = dataService.getNumeroTotalDeVoltas();
	}

	public void montarGridDeLargada() {

		gridDeLargada = corridaService.formarGrid();
		DataService.escreverArquivo("Grid de Largada \n" + gridDeLargada);
		System.out.println("Grid de Largada \n" + gridDeLargada);
	}

	public void start() {
		
		DataService.escreverArquivo("\nVolta de Apresenta��o\n");
		System.out.println("\nVolta de Apresenta��o\n");
		try {
			Thread.sleep(100);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
		
		DataService.escreverArquivo("\nCarros em Posi��o no Grid\n");
		System.out.println("\nCarros em Posi��o no Grid\n");
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
		
		DataService.escreverArquivo("\n   Bandeira Verde\n");
		System.out.println("\n   Bandeira Verde\n");

		try {
			Thread.sleep(100);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
		
		DataService.escreverArquivo("\n      Luz Verde\n");
		DataService.escreverArquivo("\n         Go...Go....Go....\n");
		System.out.println("\n      Luz Verde\n");
		System.out.println("\n         Go...Go....Go....\n");

		try {
			Thread.sleep(100);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}

		for (int voltas = 1; voltas <= numeroDeVoltas; voltas++) {
			String numeral="";
			if (voltas == 1) {
				numeral = " primeira volta";
			}else if (voltas == 2) {
				numeral = " segunda volta";
			}else if (voltas == 3) {
				numeral = " terceira volta";
			}else if (voltas == 4) {
				numeral = " quarta e �ltima volta";
			}
			
			DataService.escreverArquivo("\nRunning...pilotos na"+numeral);
			System.out.println("\nRunning...pilotos na"+numeral);
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
			
			DataService.escreverArquivo("\nPosi�oes ao final da volta "+ voltas );
			System.out.println("\nPosi�oes ao final da volta "+ voltas );
			
			String posicoes = corridaService.listarPosicoes(String.valueOf(voltas));
			System.out.println("\n-----Posi�oes-----\n "+ posicoes);
			DataService.escreverArquivo("\n-----Posi�oes-----\n "+ posicoes);
		}
		
		String menorTempoDeVolta = corridaService.getMenorTempoDaVolta();
		System.out.println("\n   Menor tempo de volta \n" + menorTempoDeVolta);
		DataService.escreverArquivo("\n   Menor tempo de volta \n" + menorTempoDeVolta);
		DataService.escreverSaida();
	}
	
}
