package repository;

import java.util.ArrayList;
import java.util.List;

import model.DataRow;
import model.Piloto;

public class PilotoRepository  {

	private static List<Piloto> pilotos;

	static {
		pilotos = new ArrayList<>();
	}
	
	public PilotoRepository() {
		
	}
	
	public void create() {
		Piloto piloto1 = new Piloto("002", "K.RAIKKONEN");
		Piloto piloto2 = new Piloto("011", "S.VETTEL");
		Piloto piloto3 = new Piloto("015", "F.ALONSO");
		Piloto piloto4 = new Piloto("023", "M.WEBBER");
		Piloto piloto5 = new Piloto("033", "R.BARRICHELLO");
		Piloto piloto6 = new Piloto("038", "F.MASSA");
		pilotos.add(piloto1);
		pilotos.add(piloto2);
		pilotos.add(piloto3);
		pilotos.add(piloto4);
		pilotos.add(piloto5);
		pilotos.add(piloto6);

	}
	
	public int informarNumeroDePilotos() {
		return pilotos.size();
	}
	
	public String findByCodigo(String codigo) {
		for (Piloto piloto : pilotos) {
			if (piloto.getCodigo().equalsIgnoreCase(codigo)) {
				return piloto.getNome();
			}
		}
		return null;
	}

	public String findByName(String nome) {
		for (Piloto piloto : pilotos) {
			if (piloto.getNome().equalsIgnoreCase(nome)) {
				return piloto.getCodigo();
			}
		}
		return null;
	}
	
	public String findAll() {
		String resultado = "{\n";
		for (Piloto piloto : pilotos) {
			resultado = resultado + "{\n" + "codigo:"+piloto.getCodigo()+","+"\n"
							+ "nome:"+piloto.getNome()+"\n"+ "}\n";
			}
		resultado = resultado + "}";
		return resultado;
	}

}
