package repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import model.DataRow;

public class DataRepository extends DataRow {

	private static List<DataRow> registroDeVoltas;
	public static int numeroTotalDeVoltas;
	static {
		registroDeVoltas = new ArrayList<>();
		numeroTotalDeVoltas = 4;
	}

	public void create(DataRow dr) {
		
		registroDeVoltas.add(dr);

	}
	
	public void ordenar() {
		
		Collections.sort(registroDeVoltas, DataRow.horaComparator);
		
	}

	public List<DataRow> findByVolta(String volta) {
		List<DataRow> registroVolta = new ArrayList<>();
		for (DataRow dr : registroDeVoltas) {
			if (dr.getVolta().equalsIgnoreCase(volta)) {
				registroVolta.add(dr);
			}
		}
		Collections.sort(registroDeVoltas, DataRow.horaComparator);
		return registroVolta;
	}

	public List<DataRow> findByCodigo(String codigo) {
		List<DataRow> registroCodigo = new ArrayList<>();
		for (DataRow dr : registroCodigo) {
			if (dr.getVolta().equalsIgnoreCase(codigo)) {
				registroCodigo.add(dr);
			}
		}
		return registroCodigo;
	}
	
	public List<DataRow> findByNome(String nome) {
		List<DataRow> registroNome = new ArrayList<>();
		for (DataRow dr : registroNome) {
			if (dr.getVolta().equalsIgnoreCase(nome)) {
				registroNome.add(dr);
			}
		}
		return registroNome;
	}
	

	public String findByMenorTempoDaVolta( ) {
		
		Collections.sort(registroDeVoltas, DataRow.tempoDaVoltaComparator);
		String volta = registroDeVoltas.get(0).getVolta();
		String Nome = registroDeVoltas.get(0).getNome();
		String tempoDaVolta = registroDeVoltas.get(0).getTempoDaVolta();
		
		String retorno = volta+"     "+Nome+"     "+tempoDaVolta;
		return retorno;
		
		
	}

}
