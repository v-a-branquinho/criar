package repository;

import java.util.Collections;
import java.util.List;

import model.DataRow;

public class CorridaRepository {

	private String gridDeLargada = "";

	DataRepository dataRepository = new DataRepository();

	public CorridaRepository() {
		super();
	}

	public String formarGrid() {
		gridDeLargada += 
				"Primeira Fila " 
				+ "\n 038   -   F.Massa " 
				+ "\n                    033   -   R.Barrichello \n" 
				+ "Segunda Fila "
				+ "\n 002   -   K.Raikkonen " 
				+ "\n                    023   -   M.Webber \n"
				+ "Terceira Fila " 
				+ "\n 015   -   F.Alonso "
				+ "\n                    011   -   S.Vettel \n";
		return gridDeLargada;
	}

	public String listarPosicoesPorVolta(String volta) {
		String posicoesVolta = "";
		List<DataRow> listVolta = dataRepository.findByVolta(volta);
		Collections.sort(listVolta, DataRow.horaComparator);
		for (DataRow dr : listVolta) {
			String nome = dr.getNome();
			posicoesVolta+=nome+"\n";
		}
		
		return posicoesVolta;
	}
}
