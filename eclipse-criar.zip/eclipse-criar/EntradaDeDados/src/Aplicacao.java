import factory.CorridaFactory;
import service.DataService;

public class Aplicacao {
	
	public static void main(String[] args) {
		
		ReadMe.escreverReadMe();
		
		DataService.lerArquivo();
		
		CorridaFactory.getInstance();
		
	}
}
